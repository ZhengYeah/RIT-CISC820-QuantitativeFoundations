%%%%%%%%
Results can by produced by executing `script.m` file (need some uncomments).
%%%%%%%%


File structure:

|- fun_1.m (function definition)
|- fun_1_gradient.m (gradient functions)
|- fun_1_hessin.m (Hessin function)
|- adam_optimizer.m (Adam implemetation)
|- ...
