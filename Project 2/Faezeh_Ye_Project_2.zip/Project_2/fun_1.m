function res = fun_1(x)
i = 1:1:100;
x = x .^ 2;
res = dot(i, x); 
end

