function res = fun_1_gradient(x)
i = 2:2:200;
i = i';
res = i .* x;
end