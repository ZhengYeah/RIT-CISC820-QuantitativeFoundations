function res = fun_1_hessin(x)
i = 2:2:200;
res = diag(i); 
end