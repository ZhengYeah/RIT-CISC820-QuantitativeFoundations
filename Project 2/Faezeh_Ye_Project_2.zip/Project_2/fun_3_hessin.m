function res = fun_3_hessin(x)
res = [-400 * x(2) + 1200 * x(1)^2 + 2, -400 * x(1); -400 * x(1), 200];  
end

