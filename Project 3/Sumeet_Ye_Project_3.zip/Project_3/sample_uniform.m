function X = sample_uniform(N,a,b)

X = a + (b-a)*rand(N,1);